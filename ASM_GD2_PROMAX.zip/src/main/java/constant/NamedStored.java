package constant;

public class NamedStored {
	public static final String FIND_USERS_LIKED_BY_VIDEO_HREF ="User.FindListLikedByVideoHref";
}
