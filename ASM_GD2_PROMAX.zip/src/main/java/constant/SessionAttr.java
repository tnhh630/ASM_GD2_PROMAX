package constant;

public class SessionAttr {

	public static final String CURRENT_USER = "currentUser";
}
